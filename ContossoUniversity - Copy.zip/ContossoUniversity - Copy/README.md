# ContossoUniversity
contosso university project in dotnet for backend and frontend in angular
