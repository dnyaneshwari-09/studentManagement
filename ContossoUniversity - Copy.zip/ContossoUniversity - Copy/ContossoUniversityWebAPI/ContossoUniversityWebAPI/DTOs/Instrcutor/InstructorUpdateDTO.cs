﻿namespace contoso.Dtos.Instrcutor
{
    public class InstructorUpdateDTO
    {
        public string LastName { get; set; }
        public string FirstMidName { get; set; }
        public DateTime HireDate { get; set; }
    }
}
