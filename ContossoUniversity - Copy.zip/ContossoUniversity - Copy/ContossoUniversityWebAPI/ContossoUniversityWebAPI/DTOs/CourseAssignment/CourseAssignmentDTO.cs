﻿namespace contoso.Dtos.CourseAssignment
{
    public class CourseAssignmentDTO
    {
        public int CourseAssignmentId { get; set; }
        public int CourseID { get; set; }
        public int InstructorID { get; set; }
    }
}
