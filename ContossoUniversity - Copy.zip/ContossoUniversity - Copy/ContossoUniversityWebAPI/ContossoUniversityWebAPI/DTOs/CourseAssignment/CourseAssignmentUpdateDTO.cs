﻿namespace contoso.Dtos.CourseAssignment
{
    public class CourseAssignmentUpdateDTO
    {
        public int CourseID { get; set; }
        public int InstructorID { get; set; }
    }
}
