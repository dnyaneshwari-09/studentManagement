﻿namespace contoso.Dtos.OfficeAssignment
{
    public class OfficeAssignmentDTO
    {
        public int InstructorID { get; set; }
        public string Location { get; set; }
    }
}
