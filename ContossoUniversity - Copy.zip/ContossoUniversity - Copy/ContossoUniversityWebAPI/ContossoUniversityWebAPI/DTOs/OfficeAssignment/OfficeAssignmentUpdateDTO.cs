﻿namespace contoso.Dtos.OfficeAssignment
{
    public class OfficeAssignmentUpdateDTO
    {
        public string Location { get; set; }
    }
}
