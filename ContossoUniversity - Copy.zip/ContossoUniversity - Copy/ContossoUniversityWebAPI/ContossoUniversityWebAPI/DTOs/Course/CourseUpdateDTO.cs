﻿namespace contoso.Dtos.Course
{
    public class CourseUpdateDTO
    {
        public string Title { get; set; }
        public int Credits { get; set; }
        public int DepartmentID { get; set; }
    }
}
