export interface Course {
  courseID: number;
  title: string;
  credits: number;
  departmentID: number;
}
