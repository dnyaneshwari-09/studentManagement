export interface UserRegistration {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: string;
}
