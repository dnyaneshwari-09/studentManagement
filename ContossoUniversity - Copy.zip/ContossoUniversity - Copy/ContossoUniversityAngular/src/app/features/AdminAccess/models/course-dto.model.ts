export class CourseDto {
  courseID: number = 0;
  title: string = '';
  credits: number = 0;
  departmentID: number = 0;
}
