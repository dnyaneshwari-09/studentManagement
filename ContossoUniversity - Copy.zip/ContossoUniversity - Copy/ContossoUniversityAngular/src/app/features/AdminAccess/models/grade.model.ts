export enum Grade {
  A = 1,
  B,
  C,
  D,
  F,
}
