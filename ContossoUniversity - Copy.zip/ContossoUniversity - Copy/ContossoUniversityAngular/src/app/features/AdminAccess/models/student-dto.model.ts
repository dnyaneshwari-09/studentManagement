export class StudentDto {
  id: number = 0;
  lastName: string = '';
  firstMidName: string = '';
  enrollmentDate: Date = new Date();
}
