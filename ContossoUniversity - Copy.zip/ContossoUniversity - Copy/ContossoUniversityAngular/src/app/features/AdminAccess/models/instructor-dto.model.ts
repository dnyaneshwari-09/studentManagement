export class InstructorDto {
  id: number = 0;
  lastName: string = '';
  firstMidName: string = '';
  hireDate: Date = new Date();
}
